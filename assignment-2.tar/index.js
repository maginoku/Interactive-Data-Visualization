export {default} from "./822a87e6b376b696@228.js";
